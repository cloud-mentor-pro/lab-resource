export const handler = (event, context, callback) => {
    let body = Object.fromEntries(new URLSearchParams(event.body));

    let response = {
        "statusCode": 200,
        "headers": {
          "Content-Type": "application/json"
        },
        "isBase64Encoded": false,
        "body": JSON.stringify(body)
    };
    callback(null, response);
};