import { MediaPackageVodClient, DescribeAssetCommand } from "@aws-sdk/client-mediapackage-vod";

export const handler = async (event, context, callback) => {
    const client = new MediaPackageVodClient({region: process.env.AWS_REGION});
    const command = new DescribeAssetCommand({Id: process.env.assetId});
    const res = await client.send(command);
    
    let response = {
        "headers" : {"content-type": "application/json"},
        "isBase64Encoded": false
    };
    
    if(res.$metadata.httpStatusCode===200) {
            const url = res.EgressEndpoints[0].Url;
            const path = url.replace(/https\:\/\/.*\.amazonaws\.com/,"");
            response.statusCode = 200;
            response.body = "{\"result\": \""+path+"\"}";      
    } else {
            response.statusCode = 500;
            response.body = "{\"result\": \"Playback URL not found!\"}";      
    }
    
    return response;

};