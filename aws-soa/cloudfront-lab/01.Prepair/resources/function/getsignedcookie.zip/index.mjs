import { getSignedCookies } from "@aws-sdk/cloudfront-signer";

export const handler = function(event, context, callback) {
  const websiteDomain = process.env.websiteDomain;
  const cloudFrontKeypairId = process.env.cloudFrontKeypairId;
  const cloudFrontPrivateKey = process.env.cloudFrontPrivateKey;
  const sessionDuration = parseInt(process.env.sessionDuration,10);
  
  const tempSplit = cloudFrontPrivateKey.replace(/--- /gi,'---\n').replace(/ ---/gi,'\n---').split('\n');
  const privateKey = tempSplit[0] +'\n'+ tempSplit[1].replace(/ /gi, '\n') +'\n'+ tempSplit[2];
  
  const policy = JSON.stringify({
    Statement: [{
        Resource: 'http*://' + websiteDomain + '/*',
        Condition: {
            DateLessThan: {
                'AWS:EpochTime':
                Math.floor(new Date().getTime() / 1000) + sessionDuration
            }
        }
    }]
  });
  
  let signedCookies = getSignedCookies({
                        keyPairId: cloudFrontKeypairId, 
                        policy: policy,
                        privateKey: privateKey,
                      });

  let options = '; Path=/';
  let response = {
    statusCode: 200,
    multiValueHeaders: {
        'Set-Cookie': [
            'CloudFront-Policy=' + signedCookies['CloudFront-Policy'] + options,
            'CloudFront-Key-Pair-Id=' + signedCookies['CloudFront-Key-Pair-Id'] + options,
            'CloudFront-Signature=' + signedCookies['CloudFront-Signature'] + options
        ]
    },
    body: "{\"result\":\"successful\"}"
  };
  
  callback(null, response);
};